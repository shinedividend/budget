from django.apps import AppConfig


class BudgetdataConfig(AppConfig):
    name = 'budgetdata'
